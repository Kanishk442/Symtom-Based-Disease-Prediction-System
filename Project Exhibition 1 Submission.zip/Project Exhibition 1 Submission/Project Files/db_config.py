# db_config.py

# Database connection details
DB_HOST = "localhost"  # Replace with your database host
DB_USER = "root"  # Replace with your database username
DB_PASSWORD = "ktom2005"  # Replace with your database password
DB_NAME = "health_management_2"  # Replace with your database name
